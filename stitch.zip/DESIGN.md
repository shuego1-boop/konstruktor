# Design System Specification: The Intelligent Canvas

## 1. Overview & Creative North Star
**Creative North Star: "The Curated Workspace"**

This design system moves away from the sterile, "boxy" nature of traditional SaaS builders. Instead, it treats the quiz-building experience as a high-end editorial desk—a place where logic meets intuition. We achieve a "Smart Assistant" vibe not through intrusive pop-ups, but through a layout that feels anticipatory, breathing with the user. 

By leveraging **intentional asymmetry**, **tonal layering**, and **expansive Cyrillic typography**, we create an environment that feels premium, professional, and undeniably warm. We reject the "default" look by banning harsh 1px borders and rigid white backgrounds, replacing them with a sophisticated interplay of tinted surfaces and soft, ambient depth.

---

## 2. Color & Surface Philosophy
Our palette is rooted in the depth of `primary` (#2E0052) and the energy of `secondary` (#944930). We avoid the clinical coldness of pure white (#FFFFFF) in favor of `surface` (#F8F9FE), which acts as a tinted, comfortable stage for complex tasks.

### The "No-Line" Rule
To achieve a signature premium feel, **1px solid borders for sectioning are strictly prohibited.** 
*   **The Rule:** Boundaries must be defined solely through background color shifts.
*   **Implementation:** Place a `surface-container-highest` navigation rail against a `surface` workspace. Use `surface-container-low` for secondary panels. The eye should perceive structure through "blocks of light," not "drawn lines."

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of fine paper or frosted glass. Use the tier system to communicate importance:
*   **Base:** `surface` (#F8F9FE) – The main canvas.
*   **Structural Sections:** `surface-container-low` (#F2F3F8) – Large sidebars or background groupings.
*   **Active Workspaces:** `surface-container-highest` (#E1E2E7) – The focused area where the user is currently typing or editing.
*   **Floating Elements:** `surface-container-lowest` (#FFFFFF) – Reserved for cards that need to "pop" off the page.

### Signature Textures & Glassmorphism
*   **The Gradient Soul:** For primary CTAs and major header backgrounds, use a linear gradient from `primary` (#2E0052) to `primary_container` (#4B0082). This adds a "lithographic" depth that flat hex codes lack.
*   **Glass Layers:** Use `surface_variant` at 60% opacity with a `20px` backdrop blur for floating toolbars or modal overlays. This ensures the workspace remains visible but softened, maintaining context without clutter.

---

## 3. Typography: The Editorial Voice
We utilize **Manrope**, a modern sans-serif with exceptional Cyrillic legibility and a friendly, open geometric structure.

*   **Display & Headline (The Authority):** Use `display-lg` to `headline-sm` for high-impact titles. These should feel intentional and spacious. In Russian, where word lengths vary significantly, use `0.5` or `1` tracking for headers to maintain a "tight" editorial look.
*   **Title & Body (The Assistant):** Use `title-md` for question labels and `body-lg` for primary inputs. The transition from Title to Body should be subtle—distinguished by weight (Medium vs Regular) rather than just size.
*   **Label (The Metadata):** Use `label-md` for micro-copy and helper text. Always use `on-surface-variant` (#4C4451) to ensure it feels secondary but remains accessible.

---

## 4. Elevation & Depth
In this system, "Elevation" is a state of light, not a shadow effect.

*   **Tonal Layering:** Depth is achieved by "stacking." A `surface-container-lowest` card sitting on a `surface-container-low` background creates a natural lift.
*   **Ambient Shadows:** If a floating state is required (e.g., a dragged quiz question), use an extra-diffused shadow: `box-shadow: 0 12px 40px rgba(46, 0, 82, 0.06)`. Note the tint: the shadow uses the `primary` hue, not black, to simulate natural light.
*   **The "Ghost Border" Fallback:** If a border is essential for accessibility, use `outline-variant` (#CEC3D3) at **15% opacity**. It should be a suggestion of a line, felt rather than seen.

---

## 5. Components

### Buttons & CTAs
*   **Primary:** A gradient of `primary` to `primary_container`. Corner radius: `xl` (1.5rem). Hover state: Slight scale-up (1.02x) with a subtle increase in shadow spread.
*   **Secondary:** `secondary_fixed` (#FFDBD0) background with `on_secondary_fixed` (#3A0B00) text. This warm peach provides a "human" counterpoint to the deep purple.
*   **Tertiary:** No background. Use `primary` text with a `surface-container-high` background on hover.

### Quiz Building Cards
*   **Visual Style:** Forbid divider lines within cards. Separate the "Question" area from the "Answers" area using a vertical `spacing-6` (1.5rem) and a subtle background shift to `surface-container-low`.
*   **Rounding:** Always `lg` (1rem) for containers; `md` (0.75rem) for nested elements like input fields or selection chips.

### Interactive Inputs
*   **Stateful Transitions:** On focus, an input field should not just change border color (which we avoid). Instead, the background should shift from `surface-container-high` to `surface-container-lowest`, and a soft "glow" using `surface_tint` at 10% opacity should appear.
*   **Checkboxes & Radios:** Use `primary` for selected states. Use `secondary_container` for the "hover" circle around the icon to provide a warm, tactile feedback.

### The "Smart Assistant" Panel
A unique component for this system: A floating, semi-transparent side-panel (using Glassmorphism) that suggests quiz improvements. Use `tertiary_fixed` (#E8DEFF) for highlight icons to differentiate "AI/Smart" features from standard UI.

---

## 6. Do's and Don'ts

### Do
*   **DO** use whitespace as a functional tool. If two elements feel cluttered, increase spacing using the `spacing-8` or `spacing-10` tokens rather than adding a line.
*   **DO** use the `secondary` (Peach/Orange) tones for "Positive" actions or "Human" feedback—it breaks the "cold tech" vibe.
*   **DO** ensure Cyrillic text has adequate line-height (`1.5` for body text) to accommodate the denser anatomy of Russian characters.

### Don't
*   **DON'T** use `error` (#BA1A1A) for simple warnings. Reserve it for critical failures. Use the `secondary` palette for "soft" errors or suggestions.
*   **DON'T** use 100% black for text. Always use `on-surface` (#191C1F) to maintain the soft, premium contrast.
*   **DON'T** mix rounding scales. If a container is `lg` (16px), its internal buttons should be `md` (12px) or `lg` to maintain visual harmony.